<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();


//add column in database table
	$enrolled_class_id = array(
	    'enrolled_class_id' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('payment', $enrolled_class_id);

	$instructor_revenue_amount = array(
	    'instructor_revenue_amount' => array(
	        'type' => 'float',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('payment', $instructor_revenue_amount);

	$admin_reward_amount = array(
	    'admin_reward_amount' => array(
	        'type' => 'float',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('payment', $admin_reward_amount);

	$project_title = array(
	    'project_title' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 255,
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('projects', $project_title);

	$project_file = array(
	    'project_file' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 255,
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('projects', $project_file);


	$last_withdrawan_payment_id = array(
	    'last_withdrawan_payment_id' => array(
	        'type' => 'int',
	        'constraint' => 11,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('user', $last_withdrawan_payment_id);

	$payment_keys = array(
	    'payment_keys' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('user', $payment_keys);

	$updated_date = array(
	    'updated_date' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 50,
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('watch_histories', $updated_date);

	$added_date = array(
	    'added_date' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 50,
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('watch_histories', $added_date);

	$in_enrolment = array(
	    'in_enrolment' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('watch_histories', $in_enrolment);









	// CREATING TABLE
	$enrolment_settings = array(
	    'id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'unsigned' => TRUE,
	        'auto_increment' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'type' => array(
	        'type' => 'VARCHAR',
	        'constraint' => '255',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'description' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_field($enrolment_settings);
	$CI->dbforge->add_key('id', TRUE);
	$attributes = array('collation' => "utf8_unicode_ci");
	$CI->dbforge->create_table('enrolment_settings', TRUE);

	$CI->db->insert('enrolment_settings', array('type' => 'student_enrolment_process', 'description' => 'class_progress'));
	$CI->db->insert('enrolment_settings', array('type' => 'enrolment_progress_percentage', 'description' => '50'));
	$CI->db->insert('enrolment_settings', array('type' => 'type_of_lesson_completion', 'description' => 'percentage'));
	$CI->db->insert('enrolment_settings', array('type' => 'lesson_completion_percentage', 'description' => '20'));
	$CI->db->insert('enrolment_settings', array('type' => 'lesson_completion_duration', 'description' => '180'));




	// CREATING TABLE
	$lesson_watching_time = array(
	    'lesson_watching_time_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'unsigned' => TRUE,
	        'auto_increment' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'user_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'class_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'lesson_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'duration_arr' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_field($lesson_watching_time);
	$CI->dbforge->add_key('lesson_watching_time_id', TRUE);
	$attributes = array('collation' => "utf8_unicode_ci");
	$CI->dbforge->create_table('lesson_watching_time', TRUE);


	// CREATING TABLE
	$payout_reports = array(
	    'payout_report_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'unsigned' => TRUE,
	        'auto_increment' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'payout_report_user_id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'payout_amount' => array(
	        'type' => 'float',
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'payout_status' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 100,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'message' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'added_date' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 100,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'updated_date' => array(
	        'type' => 'VARCHAR',
	        'constraint' => 100,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_field($payout_reports);
	$CI->dbforge->add_key('payout_report_id', TRUE);
	$attributes = array('collation' => "utf8_unicode_ci");
	$CI->dbforge->create_table('payout_reports', TRUE);



	// CREATING TABLE
	$revenue_settings = array(
	    'id' => array(
	        'type' => 'INT',
	        'constraint' => 11,
	        'unsigned' => TRUE,
	        'auto_increment' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'type' => array(
	        'type' => 'VARCHAR',
	        'constraint' => '255',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    ),
	    'description' => array(
	        'type' => 'longtext',
	        'default' => null,
	        'null' => TRUE,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_field($revenue_settings);
	$CI->dbforge->add_key('id', TRUE);
	$attributes = array('collation' => "utf8_unicode_ci");
	$CI->dbforge->create_table('revenue_settings', TRUE);

	$CI->db->insert('revenue_settings', array('type' => 'instructor_revenue_per_subscription', 'description' => '70'));
	$CI->db->insert('revenue_settings', array('type' => 'admin_revenue_per_subscription', 'description' => '20'));
	$CI->db->insert('revenue_settings', array('type' => 'admin_reward_per_classes', 'description' => '10'));
	$CI->db->insert('revenue_settings', array('type' => 'minimum_withdrawal_amount', 'description' => '10'));



	// update VERSION NUMBER INSIDE SETTINGS TABLE
	$settings_data = array( 'description' => '1.1');
	$CI->db->where('type', 'version');
	$CI->db->update('settings', $settings_data);
?>