<?php
require APPPATH . '/libraries/TokenHandler.php';
//include Rest Controller library
require APPPATH . 'libraries/REST_Controller.php';

class Api_student extends REST_Controller {

	protected $token;
	public function __construct() 
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		// creating object of TokenHandler class at first
		$this->tokenHandler = new TokenHandler();
		header('Content-Type: application/json');
	}
	

	public function token_data_get($auth_token)
	{
		//$received_Token = $this->input->request_headers('Authorization');
		if (isset($auth_token)) {
		  try
		  {

		    $jwtData = $this->tokenHandler->DecodeToken($auth_token);
		    return json_encode($jwtData);
		  }
		  catch (Exception $e)
		  {
		    echo 'catch';
		    http_response_code('401');
		    echo json_encode(array( "status" => false, "message" => $e->getMessage()));
		    exit;
		  }
		}else{
		  echo json_encode(array( "status" => false, "message" => "Invalid Token"));
		}
	}

	//all logo
	public function app_logo_get() {
		$response = array();
		$logo['dark_logo'] = base_url('uploads/system_images/logo/'.get_frontend_settings('dark_logo'));
		$logo['light_logo'] = base_url('uploads/system_images/logo/'.get_frontend_settings('light_logo'));
		$logo['favicon'] = base_url('uploads/system_images/logo/'.get_frontend_settings('favicon'));
		$response['all_logo'] = $logo;
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	// Signup Api
	public function signup_post() {
		$response = array();
		$response = $this->api_model->signup_post();
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	// Verify Email Api
	public function verify_email_address_post(){
		$response = array();
		$response = $this->api_model->verify_email_address_post();
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	// Resend Verification Code Api
	public function resend_verification_code_post(){
		$response = array();
		$response = $this->api_model->resend_verification_code_post();
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	// Login Api
	public function login_post() {
		$userdata = $this->api_model->login_post();
		if ($userdata['validity'] == 1) {
		  $userdata['token'] = $this->tokenHandler->GenerateToken($userdata);
		}
		return $this->set_response($userdata, REST_Controller::HTTP_OK);
	}

	// Forget Password Api
	public function forget_password_post(){
		$response = array();
		$response = $this->api_model->forget_password_post();
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	// password reset
	public function update_password_post() {
		$response = array();
		if (isset($_POST['auth_token']) && !empty($_POST['auth_token'])) {
		  $auth_token = $_POST['auth_token'];
		  $logged_in_user_details = json_decode($this->token_data_get($auth_token), true);
		  if ($logged_in_user_details['user_id'] > 0) {
		    $response = $this->api_model->update_password_post($logged_in_user_details['user_id']);
		  }
		}else{
		  $response['status'] = 'failed';
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}



	function subscription_status_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$response['subscription_status'] = $this->api_model->subscription_status($user_details['user_id']);
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function categories_get(){
		$response = array();
		$response = $this->api_model->categories_get();
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function home_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$response = $this->api_model->home_get($user_details['user_id']);
		}else{
			$response = $this->api_model->home_get();
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function class_details_get(){
		$response = array();
		$class_id = $_GET['class_id'];
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$response = $this->api_model->class_details_get($class_id, $user_details['user_id']);
		}else{
			$response = $this->api_model->class_details_get($class_id);
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function browse_classes_get($param1 = "", $param2 = ""){
		$response = array();
		$response = $this->api_model->browse_classes_get($param1, $param2);
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function following_and_unfollow_get(){
		$response = array();
		$follower_user_id = $_GET['follower_user_id'];
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$response = $this->frontend_model->follow($follower_user_id, $user_details['user_id']);
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function following_users_get($user_id = ""){
		$response = array();
		$response = $this->api_model->following_users_get($user_id);
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function follower_users_get($user_id = ""){
		$response = array();
		$response = $this->api_model->follower_users_get($user_id);
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function user_details_get($user_id = ""){
		$response = array();
		$response = $this->api_model->user_details_get($user_id);
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function add_saved_classes_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$this->frontend_model->bookmark('add', $_GET['class_id'], $user_details['user_id']);

			$saved_classes = $this->api_model->get_saved_classes($user_details['user_id']);
			$response['saved_classes'] = $saved_classes;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function remove_saved_classes_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$this->frontend_model->bookmark('remove', $_GET['class_id'], $user_details['user_id']);
			
			$saved_classes = $this->api_model->get_saved_classes($user_details['user_id']);
			$response['saved_classes'] = $saved_classes;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function saved_classes_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$saved_classes = $this->api_model->get_saved_classes($user_details['user_id']);
			$response['saved_classes'] = $saved_classes;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function remove_watch_history_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token']) && $_GET['class_id'] > 0) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$this->api_model->remove_watch_history($user_details['user_id'], $_GET['class_id']);
			$watch_histories = $this->api_model->get_watch_histories_by_user($user_details['user_id']);
			$response['watch_histories'] = $watch_histories;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function watch_history_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$watch_histories = $this->api_model->get_watch_histories_by_user($user_details['user_id']);
			$response['watch_histories'] = $watch_histories;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function update_watch_history_get(){
		$response = array();
		$class_id = $_GET['class_id'];
		$lesson_id = $_GET['lesson_id'];
		$seconds = $_GET['seconds'];
		$is_done = $_GET['is_done'];

		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$watch_histories = $this->frontend_model->update_watch_history($class_id, $lesson_id, $seconds, $is_done, $user_details['user_id']);
			$response['message'] = 'updated';
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);

	}

	function class_lessons_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['lesson_id']) && !empty($_GET['lesson_id'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$lesson = $this->frontend_model->get_lessons($_GET['lesson_id'])->row_array();
			if($this->api_model->subscription_status($user_details['user_id'])){
				$lesson_data['lesson'] = $lesson;
				$lesson_data['subscription_status'] = 1;
			}else{
				$lesson_data['lesson'] = array();
				$lesson_data['subscription_status'] = 0;
			}
			$response = $lesson_data;
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function update_profile_photo_post(){
		$response = array();
		if (isset($_POST['auth_token']) && !empty($_POST['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_POST['auth_token']), true);
			$response = $this->api_model->update_profile_photo($user_details['user_id']);
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function payment_history_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			$payment_history = $this->frontend_model->get_payments($user_details['user_id'])->result_array();
			$response['payment_history'] = $payment_history;
			$response['site_currency'] = currency('');
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function buy_subscription_get(){
		$response = array();
		$this->load->library('session');

		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
			
			$query = $this->db->get_where('user', array('user_id' => $user_details['user_id']));
	        if ($query->num_rows() > 0) {
	        	$this->session->set_userdata('user_id', $query->row('user_id'));
	            $this->session->set_userdata('user_role', $query->row('role'));
	            $this->session->set_userdata('login_type', true);
	            $this->session->set_userdata('user_name', $query->row('first_name').' '.$query->row('last_name'));
	            $this->session->set_userdata('user_image', $query->row('photo'));

	            redirect(site_url('membership'), 'refresh');
	        }
		}
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function discussion_get(){
		$response = array();
		$all_discussions = array();
		if (isset($_GET['class_id']) && !empty($_GET['class_id'])) {
			$discussions = $this->frontend_model->get_discussions_by_class_id($_GET['class_id'])->result_array();
			foreach($discussions as $key => $discussion){
				$child_discussions = $this->frontend_model->get_child_discussions($discussion['discussion_id']);
				$discussion['child_discussions'] = $child_discussions->result_array();
				$all_discussions[$key] = $discussion;
			}
		}
		$response['all_discussions'] = $all_discussions;

		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function add_discussion_post(){
		$response = array();
		if (isset($_POST['auth_token']) && !empty($_POST['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_POST['auth_token']), true);

			$description = $this->input->post('discussion');
			if(isset($description) && !empty($description)){
				$parent_id = $this->input->post('parent_id');
				$this->frontend_model->add_discussion($user_details['user_id'], $parent_id);

				$response['status'] = 'success';
				$response['message'] = get_phrase('post_successfully_published');
			}else{
				$response['status'] = 'error';
				$response['message'] = get_phrase('field_is_empty');
			}
		}else{
			$response['status'] = 'error';
			$response['message'] = get_phrase('please_login_first');
		}

		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function delete_discussion_get(){
		$response = array();
		if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_GET['auth_token']), true);

			if(isset($_GET['discussion_id']) && !empty($_GET['discussion_id'])){
				$discussion_id = $_GET['discussion_id'];

				$this->db->where('user_id', $user_details['user_id']);
				$this->db->where('discussion_id', $discussion_id);
				$this->db->delete('discussions');

				$this->db->where('user_id', $user_details['user_id']);
				$this->db->where('parent_id', $discussion_id);
				$this->db->delete('discussions');

				$response['status'] = 'success';
				$response['message'] = get_phrase('comment_has_been_deleted');
			}else{
				$response['status'] = 'error';
				$response['message'] = get_phrase('field_is_empty');
			}
		}else{
			$response['status'] = 'error';
			$response['message'] = get_phrase('please_login_first');
		}

		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function update_profile_data_post(){
		$response = array();
		if (isset($_POST['auth_token']) && !empty($_POST['auth_token'])) {
			$user_details = json_decode($this->token_data_get($_POST['auth_token']), true);
			$this->api_model->update_profile_data($user_details['user_id']);

			$response['status'] = 'success';
			$response['message'] = get_phrase('profile_data_updated');
		}

		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function terms_and_conditions_get(){
		$response['terms_and_conditions'] = remove_js(htmlspecialchars_decode(get_frontend_settings('terms_and_condition')));
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function privacy_policy_get(){
		$response['privacy_policy'] = remove_js(htmlspecialchars_decode(get_frontend_settings('privacy_policy')));
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}

	function about_us_get(){
		$response['about_us'] = remove_js(htmlspecialchars_decode(get_frontend_settings('about_us')));
		return $this->set_response($response, REST_Controller::HTTP_OK);
	}























}