<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api_model extends CI_Model
{
	// constructor
	function __construct()
	{
		parent::__construct();
		/*cache control*/
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
	}

	function signup_post(){

		$response = array();

		$data['first_name'] = htmlspecialchars($_POST['first_name']);
		$data['last_name'] = htmlspecialchars($_POST['last_name']);
		$data['email'] = htmlspecialchars($_POST['email']);
		$data['password'] = sha1($_POST['password']);
		$verification_code = rand(100000, 999999);
		$exist_email = exist_email($data['email']);
		if(!$exist_email){
			if(filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
				$this->frontend_model->user_registration($verification_code);
				if (get_settings('email_verification')) {

		            $credentials = array('email' => $_POST['email'], 'is_verified' => 0);
	    			$query = $this->db->get_where('user', $credentials);
	    			$this->email_model->send_email_verification_mail($data['email'], $query->row('verification_code'));
                    $response['message'] = get_phrase('please_check_your_inbox_to_verify_your_email_address');
                    $response['email_verification'] = get_settings('email_verification');
		        }else {
		            $response['message'] = get_phrase('registration_successful');
			        $response['email_verification'] = get_settings('email_verification');
			        $response['status'] = 200;
			        $response['validity'] = true;
		        }

		    }else{
		    	$response['message'] = get_phrase('invalid_email_address');
            	$response['email_verification'] = get_settings('email_verification');
		        $response['status'] = 403;
		        $response['validity'] = false;
		    }
		}elseif($exist_email === 'unverified'){
			$credentials = array('email' => $_POST['email'], 'is_verified' => 0);
			$query = $this->db->get_where('user', $credentials);
			$this->email_model->send_email_verification_mail($data['email'], $query->row('verification_code'));
            $response['message'] = get_phrase('you_have_already_signed_up').'. '.get_phrase('please_check_your_inbox_to_verify_your_email_address');
            $response['email_verification'] = get_settings('email_verification');
			
		}else{
			$response['message'] = get_phrase('you_have_already_registered');
        	$response['email_verification'] = get_settings('email_verification');
	        $response['status'] = 403;
	        $response['validity'] = false;
		}
		return $response;
	}

	// Email verify
	public function verify_email_address_post(){
	    $response = array();
	    $credentials = array('email' => $_POST['email'], 'verification_code' => $_POST['verification_code'], 'status' => 0);
	    $query = $this->db->get_where('user', $credentials);
	    if($query->num_rows() > 0){
	      $this->db->where('user_id', $query->row('user_id'));
	      $this->db->update('user', array('status' => 1, 'is_verified' => 1));

	      $response['message'] = get_phrase('email_verification_successfully');
	      $response['status'] = 200;
	      $response['validity'] = true;
	    }else{
	      $response['message'] = get_phrase('verification_code_not_matched');
	      $response['status'] = 403;
	      $response['validity'] = false;
	    }

	    return $response;
  	}

  	// Resend Verification Code
	public function resend_verification_code_post(){
	    $response = array();
	    $check['email'] = $_POST['email'];
	    $credentials = array('email' => $_POST['email'], 'status' => 0);
	    $query = $this->db->get_where('user', $credentials);
	    if($query->num_rows() > 0) {
	    	$this->email_model->send_email_verification_mail($check['email'], $query->row('verification_code'));
	    	$response['message'] = get_phrase('please_check_your_inbox_to_verify_your_email_address');
	      	$response['status'] = 200;
	      	$response['validity'] = true;
	    } else{
	    	$response['message'] = get_phrase('verification_code_not_send');
	    	$response['status'] = 403;
	    	$response['validity'] = false;
	    }

	    return $response;
  	}

  	// Login mechanism
	public function login_post(){
		$userdata = array();
		$credential = array('email' => $_POST['email'], 'password' => sha1($_POST['password']), 'status' => 1);
		$query = $this->db->get_where('user', $credential);
		if ($query->num_rows() > 0) {
			$row = $query->row_array();
			$userdata['user_id'] = $row['user_id'];
			$userdata['first_name'] = $row['first_name'];
			$userdata['last_name'] = $row['last_name'];
			$userdata['email'] = $row['email'];
			$userdata['role'] = $row['role'];
			$userdata['validity'] = 1;
		} else {
			$userdata['validity'] = 0;
		}
		return $userdata;
	}

	// Forget Password
	public function forget_password_post(){
	    $response = array();
	    $email = $this->input->post('email');
	    $new_password = rand(10000, 99999);
	    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
			if($this->email_model->send_forgot_password_mail($new_password, $email) == true){
				$response['message'] = get_phrase('your_password_has_been_changed').'. '.get_phrase('please_check_the_email_for_your_new_password');
		      	$response['status'] = 200;
		      	$response['validity'] = true;
			}else{
				$response['message'] = get_phrase('user_not_found');
		    	$response['status'] = 403;
		    	$response['validity'] = false;
			}
		}else{
			$response['message'] = get_phrase('invalid_email_address');
	    	$response['status'] = 403;
	    	$response['validity'] = false;
		}

	    return $response;
  	}

  	// Reset Password
  	public function update_password_post($user_id = "")
	{
		$response = array();
		if (!empty($_POST['current_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
			$user_details = $this->crud_model->get_users($user_id)->row_array();
			$current_password = $this->input->post('current_password');
			$new_password = $this->input->post('new_password');
			$confirm_password = $this->input->post('confirm_password');
			if ($user_details['password'] == sha1($current_password) && $new_password == $confirm_password) {
				$data['password'] = sha1($new_password);
				$this->db->where('user_id', $user_id);
				$this->db->update('user', $data);
				$response['status'] = 'success';
			} else {
				$response['status'] = 'failed';
			}
		} else {
			$response['status'] = 'failed';
		}

		return $response;
	}

	function categories_get(){
		$all_categories = array();
		$categories = $this->crud_model->get_parent_categories()->result_array();

        foreach($categories as $key => $category):
			$sub_categories = $this->crud_model->get_sub_categories($category['category_id'])->result_array();
        	$all_categories[$key]['parent'] = $category;
        	$all_categories[$key]['sub'] = $sub_categories;
		endforeach;
		$response['categories'] = $all_categories;
		$response['base_url'] = base_url();
		return $response;
	}

	function saved_class_by_class_id($class_id = "", $user_id = ""){
		$this->db->where('user_id', $user_id);
		$this->db->where('class_id', $class_id);
		return $this->db->get('bookmark');
	}

	function home_get($user_id = ""){
		$response = array();
		$slider_class_list = array();
		$featured_class_list = array();
		$recommended_class_list = array();

		$slider_classes = $this->frontend_model->get_slider_classes()->result_array();
		foreach($slider_classes as $key => $slider_class):
			$slider_class['student_number'] = $this->frontend_model->get_total_watched_student($slider_class['class_id']);
			$slider_class['subscription_status'] = $this->subscription_status($user_id);

			$slider_class_list[$key] = $slider_class;
		endforeach;

		$featured_classes = $this->frontend_model->get_featured_classes()->result_array();
		foreach($featured_classes as $key => $featured_class):
			$featured_class['student_number'] = $this->frontend_model->get_total_watched_student($featured_class['class_id']);
			$user_details = $this->crud_model->get_users($featured_class['user_id'])->row_array();
			$featured_class['teacher_name'] = $user_details['first_name'].' '.$user_details['last_name'];
			$featured_class['bookmark'] = $this->saved_class_by_class_id($featured_class['class_id'], $user_id)->num_rows();

			$featured_class_list[$key] = $featured_class;
		endforeach;

		$recommended_classes = $this->frontend_model->get_recommended_classes()->result_array();
		foreach($recommended_classes as $key => $recommended_class):
			$recommended_class['student_number'] = $this->frontend_model->get_total_watched_student($recommended_class['class_id']);

			$user_details = $this->crud_model->get_users($recommended_class['user_id'])->row_array();
			$recommended_class['teacher_name'] = $user_details['first_name'].' '.$user_details['last_name'];

			$recommended_class['bookmark'] = $this->saved_class_by_class_id($recommended_class['class_id'], $user_id)->num_rows();

			$recommended_class_list[$key] = $recommended_class;
		endforeach;

		$response['slider_classes'] = $slider_class_list;
		$response['featured_classes'] = $featured_class_list;
		$response['recommended_classes'] = $recommended_class_list;

		$response['base_url'] = base_url();
		return $response;
	}

	function class_details_get($class_id = "", $student_id = ""){
		$response = array();
		$class_data = $this->crud_model->get_classes($class_id)->row_array();
		$class_details['class_id'] = $class_data['class_id'];
		$class_details['user_id'] = $class_data['user_id'];
		$class_details['class_title'] = $class_data['class_title'];
		$class_details['description'] = htmlspecialchars_decode($class_data['description']);
		$class_details['banner'] = $class_data['banner'];
		$class_details['total_duration'] = $class_data['total_duration'];

		$response['class_details'] = $class_details;

		$all_lessons = $this->frontend_model->get_active_lessons_by_class_id($class_id);

		if($student_id > 0){

			$response['following'] = $this->frontend_model->get_followers_by_follower_id($response['class_details']['user_id'], $student_id)->num_rows();
			$watch_history = $this->frontend_model->get_watch_histories($class_id, $student_id);
			if($watch_history->num_rows() > 0){
				$play_lesson = $this->frontend_model->get_lessons($watch_history->row('playing_lesson'))->row_array();
			}elseif($all_lessons->num_rows() > 0){
				$play_lesson = $all_lessons->row_array();
			}
			
			if($this->subscription_status($student_id) || $class_data['is_free'] || $play_lesson['is_free']){
				if($all_lessons->num_rows() > 0){
					$response['play_lesson'] = $play_lesson;
				}else{
					$response['play_lesson'] = array('message'=>"lesson_not_found");
				}
			}else{
				$response['play_lesson'] = array('message'=>"this_is_not_a_free_lesson");
			}

			$watched_lessons = json_decode($watch_history->row('lesson_done'), 1);
			if(is_array($watched_lessons)){
				$watched_lesson_store = array();
				foreach($watched_lessons as $lesson_id => $watched_lesson){
					array_push($watched_lesson_store, $lesson_id);
				}
				$response['watched_lesson'] = $watched_lesson_store;
			}else{
				$response['watched_lesson'] = array();
			}
			$response['subscription_status'] = $this->subscription_status($student_id);
		}else{
			$response['following'] = 0;
			$response['play_lesson'] = array('message'=>"this_is_not_a_free_lesson");
			$response['subscription_status'] = false;
			$response['watched_lesson'] = array();
			$response['play_lesson'] = array();
		}

		$response['all_lessons'] = $all_lessons->result_array();

		$response['class_owner'] = $this->crud_model->get_users($response['class_details']['user_id'])->row_array();

		$response['students'] = $this->frontend_model->get_total_watched_student($class_id);
		$response['student_recommended_level'] = $this->frontend_model->best_suited_level($class_id, 'count');
		$response['is_free_class'] = $class_data['is_free'];

		return $response;

	}


	function browse_classes_get($param1 = "", $param2 = ""){
		if(isset($_GET['search']) && $_GET['search'] != ""){
			$this->db->like('class_title', $_GET['search']);
			$this->db->or_like('short_description', $_GET['search']);
			$this->db->or_like('description', $_GET['search']);
			$this->db->or_like('level', $_GET['search']);
		}

		if(isset($_GET['recommended']) && $_GET['recommended'] != ""){
			$this->db->where('is_recommended', 1);
		}

		if(isset($_GET['featured']) && $_GET['featured'] != ""){
			$this->db->where('is_featured', 1);
		}

		//If exitst numeric data, then this parameter for pagination or category title
		if($param1 != "" && !is_numeric($param1)){
			$sub_categories = array();
			$category_id = $this->db->get_where('category', array('slugify' => $param1))->row('category_id');
			foreach($this->crud_model->get_sub_categories($category_id)->result_array() as $sub_category):
				array_push($sub_categories, $sub_category['category_id']);
			endforeach;
			$this->db->where_in('category_id', $sub_categories);
		}


		//For filter
			if(isset($_GET['pricing']) && $_GET['pricing'] == 'free'){
				$this->db->where('is_free', 1);
			}elseif(isset($_GET['pricing']) && $_GET['pricing'] == 'premium'){
				$this->db->where('is_free !=', 1);
			}

			if(isset($_GET['duration_range']) && $_GET['duration_range'] == 'less30'){
				$count_seconds = 30*60;
				$this->db->where('total_duration <=', $count_seconds);
			}elseif(isset($_GET['duration_range']) && $_GET['duration_range'] == '31to60'){
				$first_range = 31*60;
				$second_range = 60*60;
				$this->db->where('total_duration >=', $first_range);
				$this->db->where('total_duration <=', $second_range);
			}elseif(isset($_GET['duration_range']) && $_GET['duration_range'] == 'greater60'){
				$count_seconds = 60*60;
				$this->db->where('total_duration >', $count_seconds);
			}
		//End filter

		//uri segment not working here may some reason, so the param1 use for uri segment
		if($param1 != "" && is_numeric($param1)){
			$offset = $param1;
		}else{
			$offset = $param2;
		}
		if($offset != ""){
			$this->db->limit(15, $offset);
		}else{
			$this->db->limit(15);
		}

		$this->db->where('status', 'active');
		$classes = $this->db->get('classes');

		$all_classes = array();
		
		if($classes->num_rows() > 0){
			foreach ($classes->result_array() as $key => $class) {
				$teacher = $this->crud_model->get_users($class['user_id'])->row_array();
				$class['teacher'] = $teacher['first_name'].' '.$teacher['last_name'];
				$class['student_number'] = $this->frontend_model->get_total_watched_student($class['class_id']);
				$all_classes[$key] = $class;
			}
			$response['classes'] = $all_classes;
			$response['status'] = 200;
		}else{
			$response['classes'] = $all_classes;
			$response['status'] = 403;
		}
		return $response;
	}

	function following_users_get($user_id = ""){
		$response = array();
		$this->db->where('follower_user_id', $user_id);

		$this->db->from('followers');
	    $this->db->join('user', 'user.user_id = followers.user_id');
		$response['following'] = $this->db->get()->result_array();

		return $response;
	}

	function follower_users_get($user_id = ""){
		$response = array();
		$this->db->where('followers.user_id', $user_id);

		$this->db->from('followers');
	    $this->db->join('user', 'user.user_id = followers.follower_user_id');
	    $response['followers'] = $this->db->get()->result_array();

		return $response;
	}

	function user_details_get($user_id = ""){
		$response = array();
		
		$user_details = $this->crud_model->get_users($user_id)->row_array();
		$user_details['social'] = json_decode($user_details['social'], true);

		$response['profile_details'] = $user_details;
		$response['classes'] = $this->crud_model->get_classes_by_user_id($user_id)->result_array();
		$response['followers'] = $this->frontend_model->get_followers_by_user_id($user_id)->num_rows();
		$response['following'] = $this->frontend_model->get_following_by_user_id($user_id)->num_rows();
		$response['base_url'] = base_url();
		return $response;
	}

	function get_saved_classes($user_id = ""){
		$response = array();
		if($user_id == ""){
			$user_id = $this->session->userdata('user_id');
		}
		$this->db->where('bookmark.user_id', $user_id);

		$this->db->from('bookmark');
	    $this->db->join('classes', 'classes.class_id = bookmark.class_id');
		$classes = $this->db->get()->result_array();

		foreach($classes as $key => $class){
			$class['total_student'] = $this->frontend_model->get_total_watched_student($class['class_id']);

			$response[$key] = $class;
		}

		return $response;
	}

	function remove_watch_history($user_id = "", $class_id = ""){
		$this->db->where('user_id', $user_id);
		$this->db->where('class_id', $class_id);
		$query = $this->db->get('watch_histories');
		if($query->num_rows() > 0){
			$data['in_history'] = 0;
			$this->db->where('user_id', $user_id);
			$this->db->where('class_id', $class_id);
			$this->db->update('watch_histories', $data);

			$response['status'] = 'success';
			$response['message'] = get_phrase('removed_from_watch_history');
		}else{
			$response['status'] = 'error';
			$response['message'] = get_phrase('not_found');
		}
		return $response;
	}

	function get_watch_histories_by_user($user_id = ""){
		$response = array();
		if($user_id == ""){
			$user_id = $this->session->userdata('user_id');
		}
		$this->db->where('in_history', 1);
		$this->db->where('watch_histories.user_id', $user_id);
		$this->db->order_by('date', 'desc');
		$this->db->from('watch_histories');
	    $this->db->join('classes', 'classes.class_id = watch_histories.class_id');
		$histories = $this->db->get()->result_array();

		foreach($histories as $key => $history){
			$history['total_student'] = $this->frontend_model->get_total_watched_student($history['class_id']);

			$response[$key] = $history;
		}

		return $response;

	}

	function subscription_status($user_id = "") {
        $this->db->limit(1);
        $this->db->order_by('payment_id', 'desc');
        $this->db->where('user_id', $user_id);
        $payment = $this->db->get('payment');

        if($user_id > 0 && $payment->num_rows() > 0){
            if(time() <= $payment->row('expire_date')){
                $status = true;
            }else{
                $status = false;
            }
        }else{
            $status = false;
        }
        return $status;
    }

    function update_profile_photo($user_id = ""){
    	$response = array();
		if(isset($_FILES['user_image']['name']) && $_FILES['user_image']['name'] != "" && $user_id > 0){
			$data['photo'] = md5(rand(10000, 99999)).'.jpg';
			move_uploaded_file($_FILES['user_image']['tmp_name'], 'uploads/user_images/'.$data['photo']);
			resizeImage('uploads/user_images/'.$data['photo'], 'uploads/user_images/optimized/', 120);

			$this->db->where('user_id', $user_id);
			$previous_img = $this->db->get('user')->row('photo');
			if(is_file('uploads/user_images/'.$previous_img) && file_exists('uploads/user_images/'.$previous_img)){
				unlink('uploads/user_images/'.$previous_img);
				unlink('uploads/user_images/optimized/'.$previous_img);
			}

			$this->db->where('user_id', $user_id);
			$this->db->update('user', $data);

			$response['status'] = 'success';
			$response['message'] = 'Profile photo has been changed';
		}else{
			$response['status'] = 'error';
			$response['message'] = 'Something is wrong';
		}

		return $response;
    }

    function update_profile_data($user_id = ""){
    	$data['first_name'] = htmlspecialchars($this->input->post('first_name'));
    	$data['last_name'] = htmlspecialchars($this->input->post('last_name'));
    	$data['surname'] = htmlspecialchars($this->input->post('surname'));
    	$data['phone'] = htmlspecialchars($this->input->post('phone'));
    	$data['address'] = htmlspecialchars($this->input->post('address'));
    	$data['about'] = htmlspecialchars($this->input->post('about'));

    	$social['facebook'] = htmlspecialchars($this->input->post('facebook'));
    	$social['twitter'] = htmlspecialchars($this->input->post('twitter'));
    	$social['linkedin'] = htmlspecialchars($this->input->post('linkedin'));
    	$social['website'] = htmlspecialchars($this->input->post('website'));

    	$data['social'] = json_encode($social);

    	$this->db->where('user_id', $user_id);
    	$this->db->update('user', $data);
    }

















}