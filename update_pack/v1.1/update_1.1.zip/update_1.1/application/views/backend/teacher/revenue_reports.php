  <!-- Tab panes -->
  <div class="panel">
    <div class="panel-body">
      <form class="form-inline" action="<?php echo site_url('teacher/revenue_reports') ?>" method="get">
        <div class="row mb-15px">
          <div class="col-lg-offset-2 col-lg-6">
            <div id="reportrange" class="daterange daterange-inline add-ranges" data-format="MMMM D, YYYY" data-start-date="<?php echo date("F d, Y" , $timestamp_start); ?>" data-end-date="<?php echo date("F d, Y" , $timestamp_end); ?>">
              <i class="entypo-calendar"></i>
              <span id="selectedValue"><?php echo date("F d, Y" , $timestamp_start) . " - " . date("F d, Y" , $timestamp_end);?></span>
            </div>
            <input id="date_range" type="hidden" name="date_range" value="<?php echo date("d F, Y" , $timestamp_start) . " - " . date("d F, Y" , $timestamp_end);?>">
          </div>
          <div class="col-lg-2">
            <button type="submit" class="btn btn-info" id="submit-button" onclick="update_date_range();"> <?php echo get_phrase('filter');?></button>
          </div>
        </div>
      </form>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th><?php echo get_phrase('student_subscription'); ?></th>
            <th><?php echo get_phrase('admin_reward');?></th>
            <th><?php echo get_phrase('my_class_revenue');?></th>
            <th><?php echo get_phrase('total_amount');?></th>
            <th><?php echo get_phrase('Withdrawal'); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php
          $user_details = $this->crud_model->get_users($this->session->userdata('user_id'))->row_array();;
          $total_active_course = $this->crud_model->get_active_classes()->num_rows();
          $instructors_active_course = $this->crud_model->get_active_classes_by_user_id($this->session->userdata('user_id'))->num_rows();
          foreach ($payment->result_array() as $key => $payment): ?>
            <?php $total_instructor_revenue = 0; ?>
            <tr>
              <td>
                <?php $package =  $this->crud_model->get_packages($payment['package_id'])->row_array(); ?>
                <b><?php echo get_phrase($package['package_type']); ?></b>
                <br>
                <small class="text-11 text-muted"><?php echo get_phrase('paid_amount') .' <b>'. currency($payment['paid_amount']); ?></b></small>
              </td>
              <td class="text-center">
                <?php $common_fund_for_this_instructor = ($payment['admin_reward_amount']/$total_active_course)*$instructors_active_course; ?>
                <?php echo currency(round($common_fund_for_this_instructor, 3)); ?>
                <?php $total_instructor_revenue += $common_fund_for_this_instructor; ?>
              </td>
              <td>
              	<ol style="max-height: 150px; overflow-y: auto;">
                  <?php
                  $class_ids = json_decode($payment['enrolled_class_id']);

                  if(is_array($class_ids)){
                    $instructor_class_revenue_amount = $payment['instructor_revenue_amount']/count($class_ids);
                  }else{
                    $class_ids = array(0);
                    $instructor_class_revenue_amount = 0;
                  }

                  $this->db->where('user_id', $this->session->userdata('user_id'));
                  $this->db->where_in('class_id', $class_ids);
                  $revenue_classes = $this->db->get('classes');

                  foreach($revenue_classes->result_array() as $class): ?>
                    <?php $teacher_details = $this->crud_model->get_users($class['user_id'])->row_array(); ?>
                    <li>
                      <a href="<?php echo site_url('classes/'.slugify($class['class_title']).'/'.$class['class_id']); ?>" target="_blank"><?php echo $class['class_title']; ?></a>
                      <p class="p-0 mb-3" style="font-size: 10px;">
                        <a href="<?php echo site_url('user/profile/'.$teacher_details['user_id']); ?>"  target="_blank">
                          <i class="fas fa-user"></i> <?php echo $teacher_details['first_name'].' '.$teacher_details['last_name']; ?> (<b><?php echo currency(round($instructor_class_revenue_amount, 3)); ?></b>)
                        </a>
                      </p>
                    </li>
                    <?php $total_instructor_revenue += $instructor_class_revenue_amount; ?>
                  <?php endforeach; ?>
                  <?php if($instructor_class_revenue_amount <= 0)echo currency('0'); ?>
                </ol>
              </td>
              <td><?php echo currency(round($total_instructor_revenue, 3)); ?></td>
              <td>
               <?php if($user_details['last_withdrawan_payment_id'] < $payment['payment_id']){ ?>
                  <span class="badge bg-success"><?php echo get_phrase('no'); ?></span>
                <?php }else{ ?>
                  <span class="badge bg-secondary"><?php echo get_phrase('yes'); ?></span>
                <?php } ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
  </div>
</div>

<script type="text/javascript">
  'use strict';

  function update_date_range()
  {
    var x = $("#selectedValue").html();
    $("#date_range").val(x);
  }
</script>