<div class="row">
	<div class="col-md-6">
		<div class="panel">
			<div class="panel-body text-center" style="padding: 20px 10px;">
				<h3 class="text-center" style="font-weight: 700; margin: 0px;"><i class="fas fa-dollar-sign" style="background-color: #000; padding: 10px 20px; color: #fff; border-radius: 5px;"></i></h3>
				<h3 class="text-center" style="font-weight: 700; margin: 10px 0px;">
					<?php echo currency(round($total_available_balance, 2)); ?>
				</h3>
				<p class="text-center" style="font-weight: 700; margin: 0px;"><?php echo get_phrase('total_available_balance'); ?></p>
			</div>
		</div>
	</div>
	<div class="col-md-6 text-center">
		<h1><?php echo currency(round($total_available_balance, 2)); ?></h1>
		<?php if(get_revenue_settings('minimum_withdrawal_amount') <= round($total_available_balance, 2)): ?>
			<button class="btn btn-success" onclick="showAjaxModal('<?php echo site_url('teacher/send_withdrawal_request'); ?>', '<?php echo get_phrase('withdrawal_request'); ?>');"><?php echo get_phrase('send_a_withdrawal_request'); ?></button>
		<?php endif; ?>
	</div>
</div>
<div class="row">
	<div class="col-md-6">
		<div class="panel">
			<div class="panel-body" style="padding: 20px 10px;">
				<h3 class="text-center" style="font-weight: 700; margin: 0px;"><i class="fas fa-dollar-sign" style="background-color: #539f00; padding: 10px 20px; color: #fff; border-radius: 5px;"></i></h3>
				<h3 class="text-center" style="font-weight: 700; margin: 10px 0px; color: #539f00;"><?php echo currency(round($total_paid_amount->row('payout_amount'), 2)); ?></h3>
				<p class="text-center" style="color: #539f00; font-weight: 700; margin: 0px;"><?php echo get_phrase('total_withdrawal_amount'); ?></p>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="panel">
			<div class="panel-body" style="padding: 20px 10px;">
				<h3 class="text-center" style="font-weight: 700; margin: 0px;"><i class="fas fa-dollar-sign" style="background-color: #f32e65; padding: 10px 20px; color: #fff; border-radius: 5px;"></i></h3>
				<h3 class="text-center" style="font-weight: 700; margin: 10px 0px; color: #f32e65;"><?php echo currency(round($pending_amount->row('payout_amount'), 2)); ?></h3>
				<p class="text-center" style="color: #f32e65; font-weight: 700; margin: 0px;"><?php echo get_phrase('pending_amount'); ?></p>
			</div>
		</div>
	</div>
</div>


<div class="panel">
	<div class="panel-heading">
		<div class="panel-title">
			<h4><?php echo get_phrase('payout_history'); ?></h4>
		</div>
	</div>
	<div class="panel-body">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>#</th>
					<th><?php echo get_phrase('amount'); ?></th>
					<th><?php echo get_phrase('status'); ?></th>
					<th><?php echo get_phrase('request_date'); ?></th>
					<th><?php echo get_phrase('date_of_approval'); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($payouts->result_array() as $key => $payout): ?>
				<tr>
					<td><?php echo ++$key; ?></td>
					<td><?php echo currency(round($payout['payout_amount'], 2)); ?></td>
					<td>
						<?php if($payout['payout_status'] == 'pending'): ?>
							<span class="label label-danger"><?php echo get_phrase('pending'); ?></span>
						<?php else: ?>
							<span class="label label-success"><?php echo get_phrase('paid'); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo date('d M Y', $payout['added_date']); ?></td>
					<td><?php if($payout['updated_date'])echo date('d M Y', $payout['updated_date']); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>