<form action="<?php echo site_url('teacher/send_withdrawal_request/send'); ?>" method="post">
	<div class="form-group">
		<label for="withdrawal_amount"><?php echo get_phrase('withdrawal_amount').' ('.currency('').')'; ?></label>

		<input type="number" value="<?php echo round($total_available_balance, 2); ?>" class="form-control" id="withdrawal_amount" name="withdrawal_amount" placeholder="<?php echo get_phrase('withdrawal_amount'); ?>"  min="<?php echo get_revenue_settings('minimum_withdrawal_amount'); ?>" max="<?php echo $total_available_balance; ?>" disabled>
	</div>

	<div class="form-group">
		<label for="message"><?php echo get_phrase('write_your_message'); ?></label>
		<textarea name="message" id="message" class="form-control" rows="4"></textarea>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-primary"><?php echo get_phrase('submit'); ?></button>
	</div>
</form>