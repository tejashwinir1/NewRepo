<div class="row">
	<div class="col-md-7">
		<div class="panel">
			<div class="panel-body">
				<form action="<?php echo site_url('admin/student_enrolment_settings/update'); ?>" method="post">
					<label for="instructor_revenue_per_subscription">
						<?php echo get_phrase('type_of_lesson_completion'); ?>?
					</label>
					<div class="form-group">
						<input type="radio" name="type_of_lesson_completion" value="percentage" id="percentage" onclick="$('.feild').hide(); $('#lesson_completion_percentage').show();" <?php if(get_enrolment_settings('type_of_lesson_completion') == 'percentage')echo 'checked'; ?>>
						<label for="percentage"><?php echo get_phrase('percentage'); ?></label>

						<input type="radio" name="type_of_lesson_completion" value="duration" id="duration" onclick="$('.feild').hide(); $('#lesson_completion_duration').show();" style="margin-left: 10px;" <?php if(get_enrolment_settings('type_of_lesson_completion') == 'duration')echo 'checked'; ?>>
						<label for="duration"><?php echo get_phrase('duration'); ?></label>
					</div>

					<div class="form-group <?php if(get_enrolment_settings('type_of_lesson_completion') != 'percentage')echo 'd-hidden'; ?> feild" id="lesson_completion_percentage">
						<label for="lesson_completion_percentage"><?php echo get_phrase('percentage_of_lesson_tick_mark'); ?>?</label>
						<div class="input-group">
							<div class="input-group-addon">%</div>
							<input type="number" value="<?php echo get_enrolment_settings('lesson_completion_percentage'); ?>" class="form-control" id="lesson_completion_percentage" name="lesson_completion_percentage" placeholder="<?php echo get_phrase('in_percentage'); ?>"  min="0" max="100">
						</div>
					</div>

					<div class="form-group <?php if(get_enrolment_settings('type_of_lesson_completion') != 'duration')echo 'd-hidden'; ?> feild" id="lesson_completion_duration">
						<label for="lesson_completion_duration"><?php echo get_phrase('minimum_duration_to_lesson_tick_mark'); ?></label>
						<div class="input-group">
							<div class="input-group-addon"><?php echo get_phrase('seconds'); ?></div>
							<input type="number" value="<?php echo get_enrolment_settings('lesson_completion_duration'); ?>" class="form-control" id="lesson_completion_duration" name="lesson_completion_duration" placeholder="<?php echo get_phrase('count_seconds'); ?>"  min="0">
						</div>
					</div>

					<hr>

					<label for="instructor_revenue_per_subscription">
						<?php echo get_phrase('type_of_student_enrolment'); ?>?
					</label>
					<div class="form-group">
						<input type="radio" name="student_enrolment_process" value="class_progress" id="class_progress" <?php if(get_enrolment_settings('student_enrolment_process') == 'class_progress')echo 'checked'; ?> onclick="$('.feilds').hide(); $('#enrolment_progress_percentage').show();">
						<label for="class_progress"><?php echo get_phrase('class_progress'); ?></label>

						<input type="radio" name="student_enrolment_process" value="lesson_progress" id="lesson_progress" onclick="$('.feilds').hide();" style="margin-left: 10px;" <?php if(get_enrolment_settings('student_enrolment_process') == 'lesson_progress')echo 'checked'; ?>>
						<label for="lesson_progress"><?php echo get_phrase('enroll_after_completing_a_lesson'); ?></label>
					</div>

					<div class="form-group feilds <?php if(get_enrolment_settings('student_enrolment_process') != 'class_progress')echo 'd-hidden'; ?>" id="enrolment_progress_percentage">
						<label for="enrolment_progress_percentage"><?php echo get_phrase('what_percentage_do_you_want_to_enroll_in_after_completion'); ?>?</label>
						<div class="input-group">
							<div class="input-group-addon">%</div>
							<input type="number" value="<?php echo get_enrolment_settings('enrolment_progress_percentage'); ?>" class="form-control" id="enrolment_progress_percentage" name="enrolment_progress_percentage" placeholder="<?php echo get_phrase('in_percentage'); ?>"  min="0" max="100">
						</div>
					</div>

					<div class="form-group">
						<button type="submit" class="btn btn-primary"><?php echo get_phrase('save_changes'); ?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>