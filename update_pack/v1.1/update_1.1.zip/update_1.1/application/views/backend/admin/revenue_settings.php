<div class="row">
	<div class="col-md-7">
		<div class="panel">
			<div class="panel-body">
				<form action="<?php echo site_url('admin/revenue_settings/update'); ?>" method="post">

					<div class="form-group">
						<label for="admin_reward_per_classes">
							<?php echo get_phrase('overall_funding_for_each_course_from_each_subscription'); ?>
							(<?php echo get_phrase('admin_reward'); ?>)
							<i class="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="<?php echo get_phrase('this_percentage_will_get_all_the_instructors_based_on_the_number_of_their_active_classes'); ?>. <?php echo get_phrase("you_can_keep_it_to_0_if_you_want_if_you_don't_want_to_allocate_any_funds"); ?>"> </i>
						</label>

						<div class="input-group">
							<div class="input-group-addon">%</div>
							<input type="number" value="<?php echo get_revenue_settings('admin_reward_per_classes'); ?>" class="form-control" id="admin_reward_per_classes" name="admin_reward_per_classes" placeholder="<?php echo get_phrase('in_percentage'); ?>" onkeyup="calculate_revenue_percentage(this);" min="0" max="100">
						</div>
					</div>

					<div class="form-group">
						<label for="instructor_revenue_per_subscription">
							<?php echo get_phrase('instructor_revenue_per_subscription'); ?>
							<i class="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="<?php echo get_phrase('this_percentage_will_be_divided_based_on_the_classes_that_the_student_will_watch_after_purchasing_the_subscription'); ?>."></i>
						</label>

						<div class="input-group">
							<div class="input-group-addon">%</div>
							<input type="number" value="<?php echo get_revenue_settings('instructor_revenue_per_subscription'); ?>" class="form-control" id="instructor_revenue_per_subscription" name="instructor_revenue_per_subscription" placeholder="<?php echo get_phrase('in_percentage'); ?>" onkeyup="calculate_revenue_percentage(this);" min="0" max="100">
						</div>
					</div>

					<div class="form-group">
						<label for="admin_revenue_per_subscription"><?php echo get_phrase('admin_revenue_per_subscription'); ?></label>

						<div class="input-group">
							<div class="input-group-addon">%</div>
							<input type="number" value="<?php echo get_revenue_settings('admin_revenue_per_subscription'); ?>" class="form-control" id="admin_revenue_per_subscription" name="admin_revenue_per_subscription" placeholder="<?php echo get_phrase('in_percentage'); ?>"  min="0" max="100" readonly>
						</div>
					</div>

					<div class="form-group">
						<label for="minimum_withdrawal_amount"><?php echo get_phrase('minimum_withdrawal_amount').' ('.currency('').')'; ?></label>

							<input type="number" value="<?php echo get_revenue_settings('minimum_withdrawal_amount'); ?>" class="form-control" id="minimum_withdrawal_amount" name="minimum_withdrawal_amount" placeholder="<?php echo get_phrase('minimum_withdrawal_amount'); ?>"  min="1">
					</div>

					<div class="form-group">
						<button type="submit" id="revenue_settings_submit_btn" class="btn btn-primary"><?php echo get_phrase('save_changes'); ?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-5">
		<div class="panel">
			<div class="panel-body">
				<div class="alert alert-info" role="alert">
			      <strong><?php echo get_phrase("courses_enrolled_during_the_subscription_period_will_be_included_in_the_revenue"); ?>.</strong>
			    </div>
				<div class="alert alert-info" role="alert">
			      <strong><?php echo get_phrase("the_instructors_will_receive_their_revenue_after_the_expiration_of_the_student's_subscription"); ?>.</strong>
			    </div>
			    <a href="https://creativeitem.com/docs/mastery/what-is-mastery" target="_blank"><?php echo get_phrase('more_details'); ?> <i class="fas fa-arrow-right"></i></a>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	function calculate_revenue_percentage(e){
		var instructor_revenue = $('#instructor_revenue_per_subscription').val();
		var common_fund = $('#admin_reward_per_classes').val();
		var admin_revenue = 100 - (Number(instructor_revenue)+Number(common_fund));

		if(admin_revenue < 0 || admin_revenue > 100){
			error_notify('<?php echo get_phrase('you_must_keep_the_total_number_within_0%_to_100%'); ?>');
			$('#revenue_settings_submit_btn').prop("disabled", true);
		}else{
			$('#revenue_settings_submit_btn').prop("disabled", false);
			$('#admin_revenue_per_subscription').val(admin_revenue);
		}
	}
</script>