<script src="https://js.stripe.com/v3/"></script>


<div class="panel">
	<div class="panel-heading">
		<div class="panel-title">
			<h4><?php echo get_phrase('payout_history'); ?></h4>
		</div>
	</div>
	<div class="panel-body">
		<form class="form-inline" action="<?php echo site_url('admin/payout_reports') ?>" method="get">
	        <div class="row mb-15px">
	          <div class="col-lg-3">
	          	<label><?php echo get_phrase('teacher'); ?></label>
	          	<select class="form-control select2" name="teacher_id">
	          		<option value=""><?php echo get_phrase('all_teacher'); ?></option>
	          		<?php foreach($this->crud_model->get_teachers()->result_array() as $teacher): ?>
	          			<option value="<?php echo $teacher['user_id']; ?>" <?php if(isset($_GET['teacher_id']) && $_GET['teacher_id'] == $teacher['user_id'])echo 'selected'; ?>><?php echo $teacher['first_name'].' '.$teacher['last_name']; ?></option>
	          		<?php endforeach; ?>
	          	</select>
	          </div>
	          <div class="col-lg-3">
	          	<label><?php echo get_phrase('payment_status'); ?></label>
	          	<select class="form-control" name="payout_status" style="width: 100%; height: 43px;">
	          		<option value=""><?php echo get_phrase('all'); ?></option>
	          		<option value="paid" <?php if(isset($_GET['payout_status']) && $_GET['payout_status'] == 'paid')echo 'selected'; ?>><?php echo get_phrase('paid'); ?></option>
	          		<option value="pending" <?php if(isset($_GET['payout_status']) && $_GET['payout_status'] == 'pending')echo 'selected'; ?>><?php echo get_phrase('unpaid'); ?></option>
	          	</select>
	          </div>
	          <div class="col-lg-4">
	          	<label><?php echo get_phrase('date_range'); ?></label>
	            <div id="reportrange" class="daterange daterange-inline add-ranges" data-format="MMMM D, YYYY" data-start-date="<?php echo date("F d, Y" , $timestamp_start); ?>" data-end-date="<?php echo date("F d, Y" , $timestamp_end); ?>" style="height: 42px; background-color: #ffffff;">
	              <i class="entypo-calendar"></i>
	              <span id="selectedValue"><?php echo date("F d, Y" , $timestamp_start) . " - " . date("F d, Y" , $timestamp_end);?></span>
	            </div>
	            <input id="date_range" type="hidden" name="date_range" value="<?php echo date("d F, Y" , $timestamp_start) . " - " . date("d F, Y" , $timestamp_end);?>">
	          </div>
	          <div class="col-lg-2">
	            <button type="submit" class="btn btn-info" id="submit-button" onclick="update_date_range();" style="margin-top: 25px;"> <?php echo get_phrase('filter');?></button>
	          </div>
	        </div>
	    </form>
		<table class="table table-bordered" style="margin-top: 40px;">
			<thead>
				<tr>
					<th>#</th>
					<th><?php echo get_phrase('amount'); ?></th>
					<th><?php echo get_phrase('status'); ?></th>
					<th><?php echo get_phrase('date'); ?></th>
					<th><?php echo get_phrase('option'); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($payouts->result_array() as $key => $payout): ?>
					<?php $teacher_details = $this->crud_model->get_users($payout['payout_report_user_id'])->row_array(); ?>
				<tr>
					<td><?php echo ++$key; ?></td>
					<td><?php echo currency(round($payout['payout_amount'], 2)); ?></td>
					<td>
						<?php if($payout['payout_status'] == 'pending'): ?>
							<span class="label label-danger"><?php echo get_phrase('pending'); ?></span>
						<?php else: ?>
							<span class="label label-success"><?php echo get_phrase('paid'); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo date('d M Y', $payout['added_date']); ?></td>
					<td>
						<div class="bs-example">
		                  <div class="btn-group">
		                    <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
		                      <?php echo get_phrase('action'); ?> <span class="caret"></span>
		                    </button>
		                    <ul class="dropdown-menu dropdown-blue dropdown-menu-right" role="menu">
		                      <li>
		                        <a href="javascript:;" onclick="showAjaxModal('<?php echo site_url('admin/view_payout_message/'.$payout['payout_report_id']); ?>', '<?php echo get_phrase('withdrawal_message'); ?>')">
		                          <i class="entypo-eye"></i>
		                          <?php echo get_phrase('view_messagee'); ?>
		                        </a>
		                      </li>
		                      <?php if($payout['payout_status'] != 'paid'): ?>
			                      <li>
			                        <a href="<?php echo site_url('admin/instructor_payment/'.$payout['payout_report_id'].'/paypal'); ?>">
			                          <i class="fab fa-cc-paypal"></i>
			                          <?php echo get_phrase('pay_via_paypal'); ?>
			                        </a>
			                      </li>
			                      <li>
			                        <a href="javascript:;" onclick="stripe_checkout('<?php echo json_decode($teacher_details['payment_keys'])->stripe_public_key; ?>', '<?php echo $payout['payout_report_id']; ?>');">
			                          <i class="fab fa-cc-stripe"></i>
			                          <?php echo get_phrase('pay_via_stripe'); ?>
			                        </a>
			                      </li>
			                  <?php endif; ?>
		                    </ul>
		                  </div>
		                </div>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<script type="text/javascript">
  'use strict';

	function update_date_range(){
		var x = $("#selectedValue").html();
		$("#date_range").val(x);
	}


	function stripe_checkout(stripe_public_key, payout_id){
	    var createCheckoutSession = function (stripe) {
	        return fetch("<?php echo site_url('admin/instructor_payment/'); ?>"+payout_id+"/stripe", {
	            method: "POST",
	            headers: {
	                "Content-Type": "application/json",
	            },
	            body: JSON.stringify({
	                checkoutSession: 1,
	            }),
	        }).then(function (result) {
	            return result.json();
	        });
	    };

	    createCheckoutSession().then(function (data) {
	        if(data.sessionId){
	            Stripe(stripe_public_key).redirectToCheckout({
	                sessionId: data.sessionId,
	            }).then(handleResult);
	        }else{
	            handleResult(data);
	        }
	    });
	}
</script>