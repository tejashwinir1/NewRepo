<div class="container py-3">
	<?php if(subscription_status()): ?>
		<div class="row justify-content-center my-3">
			<div class="col-md-12">
				<button class="btn btn-green float-end" onclick="showAjaxModal('<?php echo site_url('classes/add_project_form?class_id='.$class_details['class_id']); ?>');">
					<i class="bi bi-plus"></i>
					<?php echo get_phrase('add_your_project'); ?>
				</button>
			</div>
		</div>
	<?php else: ?>
		<?php include "subscription_view.php"; ?>
	<?php endif; ?>

	<div class="row">
		<?php foreach($projects->result_array() as $key => $project): ?>
			<div class="col-md-6 col-lg-4 p-1">
				<div class="project-card" style="background-image: url('<?php echo base_url('uploads/projects/thumbnails/optimized/'.$project['project_thumbnail']); ?>');">
					<div class="project-card-body">
						<div class="details">
							<h4 class="text-white"><?php echo $project['project_title']; ?></h4>
							<div class="w-100 mb-2 text-14"><?php echo ellipsis($project['project_details'], 100) ?></div>
							<div class="row m-0 p-0">
								<div class="col-8 p-0">
									<button class="btn btn-green float-start text-14 btn-sm" onclick="showAjaxModal('<?php echo site_url('classes/project_details?project_id='.$project['project_id']); ?>');"><?php echo get_phrase('view_details'); ?></button>
								</div>
								<div class="col-4 p-0">
									<?php
										$likes_arr = json_decode($project['likes']);
										if(!is_array($likes_arr)){
											$likes_arr = array();
										}
									?>
									<?php if($project['user_id'] == $this->session->userdata('user_id')): ?>
										<button class="btn btn-danger float-end fw-bold" onclick="delete_ptoject('<?php echo $project['project_id']; ?>')"><i class="bi bi-trash"></i></button>
									<?php endif; ?>
									<button class="btn float-end fw-bold <?php if (array_search($this->session->userdata('user_id'), $likes_arr) !== false){echo 'mstr-color-green';}else{echo 'text-white'; } ?>" id="like_btn<?php echo $project['project_id']; ?>" onclick="project_like('<?php echo $project['project_id']; ?>');">
										<span id="show_like<?php echo $project['project_id']; ?>"><?php echo count($likes_arr); ?></span> <i class="bi bi-hand-thumbs-up"></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<script type="text/javascript">
	function project_like(project_id){
		$.ajax({
			type: 'get',
			url: '<?php echo site_url('classes/handle_project_like'); ?>',
			data:{'project_id':project_id},
			success: function(response){
				var response = JSON.parse(response);

				if(response.status > 0){
					$('#like_btn'+project_id).removeClass('text-white');
					$('#like_btn'+project_id).addClass('mstr-color-green');
					$('#show_like'+project_id).text(response.like);
				}else{
					$('#like_btn'+project_id).removeClass('mstr-color-green');
					$('#like_btn'+project_id).addClass('text-white');
					$('#show_like'+project_id).text(response.like);
				}
			}
		});
	}

	function delete_ptoject(project_id){
		$.ajax({
			type: 'get',
			url: '<?php echo site_url('classes/delete_ptoject'); ?>',
			data:{'project_id':project_id},
			success: function(response){
				load_class_data(false, '<?php echo $class_details['class_id']; ?>', 'projects');
			}
		});
	}
</script>