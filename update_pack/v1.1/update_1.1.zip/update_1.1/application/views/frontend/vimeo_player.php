<?php
	if(login_type() && $watch_history->num_rows() > 0){
		$lesson_duration = json_decode($watch_history->row('lesson_current_duration'), 1);
		if(array_key_exists($play_lesson['lesson_id'], $lesson_duration)){
			$current_duration = $lesson_duration[$play_lesson['lesson_id']];
		}else{
			$current_duration = 0;
		}
	}else{
		$current_duration = 0;
	}
?>
<?php $video_details = $this->video_model->getVideoDetails($play_lesson['lesson_src']); ?>
<div class="plyr__video-embed" id="player">
  <iframe src="<?php echo $video_details['embed_video']; ?>" frameborder="0" title="<?php echo $video_details['title']; ?>" webkitallowfullscreen mozallowfullscreen allowfullscreen
    allowtransparency
    allow="autoplay"></iframe>
</div>
<link rel="stylesheet" href="<?php echo base_url();?>assets/global/plyr/plyr.css">
<script src="<?php echo base_url();?>assets/global/plyr/plyr.js"></script>
<script>
	const player = new Plyr('#player');
	var vid = document.getElementById("player");
	var seeking = false;

	player.on('ready', event => {
		player.play();
	});
	vid.addEventListener('seeking', event => {
	  seeking = true;
	});

	setInterval(function(){
		if(player.currentTime > 0 && (Math.round(player.currentTime)%5) == 0){
			update_watch_history('<?php echo $class_details['class_id']; ?>','<?php echo $play_lesson['lesson_id']; ?>', Math.round(player.currentTime));
		}
	},1000);
</script>