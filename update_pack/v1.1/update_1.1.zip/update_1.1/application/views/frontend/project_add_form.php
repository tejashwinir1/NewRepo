<form action="<?php echo site_url('classes/added_class_project'); ?>" method="post" class="ajaxAddProjectForm d-inline-block w-100 p-3 border border-1" enctype="multipart/form-data">
	<h5><?php echo get_phrase('add_your_project'); ?></h5>
		<input type="hidden" class="form-control" value="<?php echo $class_id; ?>" id="class_id" name="class_id" required>
	<div class="mt-3">
		<label for="project_title"><?php echo get_phrase('project_title'); ?></label>
		<input type="text" class="form-control" id="project_title" name="project_title" required>
	</div>

	<div class="mt-3">
		<label for="project_details"><?php echo get_phrase('project_details'); ?></label>
		<textarea class="form-control" name="project_details" id="project_details" rows="4"></textarea>
	</div>

	<div class="mt-3">
		<label for="preview_image"><?php echo get_phrase('preview_image'); ?></label>
		<input type="file" class="form-control" id="preview_image" name="project_thumbnail" accept="image/*" required>
	</div>

	<div class="mt-3">
		<label for="project_file"><?php echo get_phrase('project_file'); ?></label>
		<input type="file" class="form-control" id="project_file" name="project_file" required>
	</div>

	<div class="mt-3">
		<button class="btn btn-secondary float-end"><?php echo get_phrase('submit'); ?></button>
	</div>
</form>

<script type="text/javascript">
	//Ajax load
	"use strict";

	$(function() {
	    //Top progress & progress bar
	    var progress = '<div class="real-top-progress"><div class="real-top-progress-bar " role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div></div>';
	    
	    //The progress bar appended on the body.
	    $('body').append(progress);

	    //The progress bar inside the progress div has been taken in a variable.
	    var progress_bar = $('.real-top-progress-bar');

	    //The form of submission to RailTeam js is defined here.(Form class or ID)
	    $('.ajaxAddProjectForm').ajaxForm({
	        beforeSend: function() {
	            var percentVal = '0%';
	            progress_bar.width(percentVal);
	            progress_bar.show();
	        },
	        uploadProgress: function(event, position, total, percentComplete) {
	            var percentVal = percentComplete + '%';
	            progress_bar.width(percentVal);
	            
	        },
	        complete: function(xhr) {
	        	setTimeout(function(){
	                progress_bar.hide();
	            }, 800);

	        	var jsonResponse = JSON.parse(xhr.responseText);
	        	
	        	if(jsonResponse.status == 'error'){
	        		error_message(jsonResponse.message);
	        	}else{
	        		$('.custom-modal').removeClass('custom-modal-show');
		        	load_class_data(false, '<?php echo $class_id; ?>', 'projects');
		        }
	        },
	        error: function()
	        {
	            //You can write here your js error message
	        }
	    });
	});
</script>