<div class="card">
  <img src="<?php echo base_url('uploads/projects/thumbnails/'.$project_details['project_thumbnail']); ?>" class="card-img-top" alt="Project thumbnail">
  <div class="card-body">
    <h5 class="card-title"><?php echo $project_details['project_title']; ?></h5>
    <p class="card-text"><?php echo $project_details['project_details']; ?></p>
    <a href="<?php echo base_url('uploads/projects/files/'.$project_details['project_file']); ?>" class="btn btn-primary" download>
    	<i class="bi bi-download"></i>
    	<?php echo get_phrase('download_project'); ?>
    </a>
  </div>
</div>